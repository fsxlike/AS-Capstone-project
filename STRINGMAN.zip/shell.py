import pseudocode
global output
output = []
#run function
def runPseudocode(f):
    f.replace('\n',';')
    _,error,output = pseudocode.run(fn,f)
    if error:print(error.as_string())
    return output
#simple script to run a file
fn = input('Enter file name->')    
file = open(fn+'.txt','r').read()
runPseudocode(file)