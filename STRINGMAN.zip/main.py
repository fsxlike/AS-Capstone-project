import random
import string
import pseudocode


class STRING_INFO:
    def __init__(self, stringtext, concisetext, symbol, symbolcount):
        self.stringtext = stringtext
        self.concisetext = concisetext
        self.symbol = symbol
        self.symbolcount = symbolcount


def runPseudocode(f):
    f.replace('\n', ';')
    callback = pseudocode.run("pseudocode", f)
    #  if error:print(error.as_string())
    if callback[1] is None:
      return [True, callback[2]]
    else:
      return [False, callback[1]]
  
    return callback


def str_gen(char):  # ASCII, '%'
    # "He%%l%o W%or%ld"
    stringLength = random.randint(30, 50)
    Randstr = ''.join(random.choices(string.ascii_lowercase + string.digits, k=stringLength))
    comp = random.randint(0, len(Randstr) - 1)

    count = 0
    newStr = ""
    conciseStr = ""
    for i in range(len(Randstr)):
        if comp == i or random.randint(1, 10) == 1:
            count += 1
            newStr += char
        newStr += Randstr[i]
        conciseStr += Randstr[i]

    return STRING_INFO(newStr, conciseStr, char, count)


def write_pseudocode(str):
    with open("pseudocode.txt", "w") as file:
        file.write(f'recordedString <- "{str}"\n')
        while True:
            lineScript = input("Write new line of pseudocode, enter !!! to quit writing\n")

            if lineScript == "!!!":
                break
            file.write(lineScript + "\n")
        file.write('OUTPUT(modifiedString)')
    return True

    # return <STRING> datatype


def shortq():
    qsStrInfo = str_gen(chr(random.randint(33, 47)))
    while True:
        print("The varaible 'recordedString' contains unnecessary characters '", qsStrInfo.symbol,"'. Write the appropriate pseudocode to remove these characters and print the modifed string. 'modifiedString' ")
        write_pseudocode(qsStrInfo.stringtext)
        file = open("pseudocode.txt", "r").read()
        result = runPseudocode(file)

        print(result)
        if result[0] == False:
          print("Check for errors in pseudocode " + result[1])
          continue
        if result[1][0] == qsStrInfo.concisetext:
          return True
        else: 
          print("You got the wrong answer from your pseudocode.")
          



shortq()