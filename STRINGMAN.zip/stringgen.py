import random
import string


def str_gen(char):  # ASCII, '%'
    # "He%%l%o W%or%ld"
    stringLength = random.randint(30, 50)
    Randstr = ''.join(random.choices(string.ascii_lowercase + string.digits, k=stringLength))
    comp = random.randint(0, len(Randstr) - 1)

    characterCount = 0
    newStr = ""
    conciseStr = ""
    for i in range(len(Randstr)):
        if comp == i or random.randint(1, 10) == 1:
            characterCount += 1
            newStr += char
        newStr += Randstr[i]
        conciseStr += Randstr[i]

    return [newStr, conciseStr, characterCount]

